#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')

len(merged.columns)
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale

merged.Percentage_UG = merged.Performance_UG/merged.UG_Scale

merged['Percentage_PG']=merged.Percentage_PG
merged['Percentage_UG']=merged.Percentage_UG

merged = merged.drop(merged.columns[[14,15,16,17,18]], axis=1)
le = preprocessing.LabelEncoder()
le.fit_transform(merged.Expected_Stipend)
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Expected_Stipend'] 
le = preprocessing.LabelEncoder()
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Internship_Location'] = le.fit_transform(merged.Internship_Location)
le = preprocessing.LabelEncoder()
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged = merged.fillna()
merged = merged.fillna('NA')
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Internship_Location'] = le.fit_transform(merged.Internship_Location)




merged.to_csv('check.csv')
from sklearn.preprocessing import OneHotEncoder
enc = OneHotEncoder()
enc.fit_transform(merged.Preferred_location)
enc.fit_transform(merged)
%clear

##---(Sat Feb 27 15:10:07 2016)---
runfile('C:/Users/vatsal/OneDrive/Date_Your_Data/start.py', wdir='C:/Users/vatsal/OneDrive/Date_Your_Data')
merged.columns
merged.Earliest_Start_Date
X_train = pd.read_csv("check.csv")
X_train.Earliest_Start_Date
pd.to_datetime(X_train['Earliest_Start_Date'])
X_train.Earliest_Start_Date=pd.to_datetime(X_train['Earliest_Start_Date'])
X_train.Earliest_Start_Date[0]
X_train.Earliest_Start_Date[0]-X_train.Earliest_Start_Date[1]
z=X_train.Earliest_Start_Date[0]-X_train.Earliest_Start_Date[1]
z[0]
z
print (z)
z.value
z.days
X_train.Start_Date = pd.to_datetime(X_train['Start_Date'])
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date).days
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date)
X_train.Time_Difference 
X_train.Time_Difference.days
X_train.Time_Difference[0]
X_train.Time_Difference[0].days
X_train.Time_Difference.apply(lambda x:x.days)
X_train.Time_Difference[0].days
X_train.Time_Difference[0].days()
X_train.Time_Difference.apply(lambda x:x.days())
X_train.Time_Difference.map(lambda x:x.days)
%clear
X_train['Time_Difference'] = X_train.Time_Difference
X_train['Time_Difference'] 
X_train['Time_Difference'].apply(lambda x:x.days)
X_train['Time_Difference'].apply(lambda x:days)
X_train['Time_Difference'].apply(lambda x:x+1)
%clear
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date)
X_train['Time_Difference'] = X_train.Time_Difference


for i in range(len(X_train)):    X_train['Time_Difference'][i]=X_train.Time_Difference[i].days
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date).astype('timedelta64[d]')
import pandas as pd
import numpy as np
from sklearn import preprocessing
#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')

len(merged.columns)
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale

merged.Percentage_UG = merged.Performance_UG/merged.UG_Scale

merged['Percentage_PG']=merged.Percentage_PG
merged['Percentage_UG']=merged.Percentage_UG

merged = merged.drop(merged.columns[[14,15,16,17,18]], axis=1) 



#numeric_cols = ['Minimum_Duration','Is_Part_Time',
#                'Percentage_PG','Percentage_UG',
#                'Performance_12th','Performance_10th',
#                'No_of_openings','Stipend1','Stipend2',
#                'Internship_Duration(Months)','PR,UI','Marketing','Media','Social','Design','Web,Development','Business','Research','Writing','Plan','Creative','Process','Database','Strategy','Designing','Analysis','Facebook','Communication','Rest','Android','Presentation','Media Marketing','Twitter','Social Media Marketing','Operations','Java','Quality','HTML','Blogs','Digital Marketing','PHP','Market Research','Recruitment','Testing','CSS','Planning','API','Editing','Content Writing','Innovative','Lead Generation','Mobile App','SQL','Accounts','Reporting','JavaScript','Documentation','iOS','Branding','ACTING','Analytics','Initiative','Advertising','Cold Calling','Sourcing','ERP','NGO','Environment','Networking','Production','MySQL','ISO','Marketing Strategy','Survey','Visio','App Development','Front End','web development','Integration','HTML5','jQuery','Server','Coding','MBA','Content Creation','Reading','B2B','Content Development','Storm','E-commerce','Databases','Programming','Wordpress','Outreach','NABL','Web Design','Architecture','Web Application','Adobe','Scala','UI/UX','Python','Mac','Retail','Digital Media','Product Development','Data Collection','Algorithm','LESS','Email Marketing','Screening','Bootstrap','Finance','Content Marketing','Communication Skil','Hiring','Negotiation','Administration','Communication Skills','CSS3','Infographic','Youtube','CRM','CAD','Infographics','Access','Editorial','ARM,AJAX','.NET','Co-ordination','Ownership','Algorithms','Node','Drafting','Blogging','Animation','Teaching','Blogger','Relationship Management','3d','HTTP','Press Release','Accounting','Android App Development','Adobe Photoshop','Photography','Software Development','Social Networking','AngularJS','AWS','Secondary Research','Recruiting','Client Servicing','Leadership','Content Writer','Web Services','Payroll','Prospecting','Graphic Designing','Proofreading','Data Entry','Flex','Creativity','Data Management','Convincing','GATE','Social Media Management','Machine Learning','Client Relations','Web Applications','XML','MVC','HTML/CSS','Google+','Typing','Sketch','UI Design','Visual Design','Creative Writing','Graphic Designer','Product Design','PERL','Hindi','Chef',Sales Process,ASP.NET,Django,Public Relations,CMS,Vendor Management,Content Strategy,Client Relationship,Creative Design,C#,JSON,Linux,Client Interaction,Manufacturing,Customer Relationship Management,Recruitment Process,Business Relation,Talent Acquisition,CorelDRAW,Big Data,Material Design,Market Analysis,Adobe Illustrator,REST API,Tally,Electronics,Bee,C++,Online Research,Mockups,Front End Development,Gif,Product Management,MongoDB,Primary Research,Healthcare,Data Analytics,Google Analytics,Core PHP,B2B Sales,Social Media Tools,Node.js,Ruby,Drawing,Brand Promotion,Mechanical,Automobile,Lifestyle,Writing Blogs,CodeIgniter,Writing Skills,SQL Server,Logo Design,Project Management,API Integration,Client Communication,Growth Hacking,Interior Design,Personality,SAP,Scripting,Android Application Development,Event Management,Blog Writing,Statistics,Typography,Scalability,Assembly,Conceptualization,Microsoft,MVC Framework,PSD,Web Technologies,Web Application Development,Joomla,Image Processing,REST APIs,Data Structure,Confidence,Electrical,Counseling,Inside Sales,Organizational Skills,Video Editing,Data Structures,Mobile Application Development,PhoneGap,Storytelling,MySQL.,Ionic,Design Skills,Corporate Sales,Entrepreneurship,Films,Foundation,Payment Gateway']

"""           
Drop Profile
Start Date 
Stop Date
Internship Profile
Skills Required
Stipend
"""
#Converting categorical variables to numeric attributes 
merged = merged.fillna('NA')         
le = preprocessing.LabelEncoder()
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Internship_Location'] = le.fit_transform(merged.Internship_Location)

#merged.to_csv('check.csv')

#Removing unwanted features and cleaning earliest start date
X_train = pd.read_csv("check.csv")
X_train.Earliest_Start_Date=pd.to_datetime(X_train['Earliest_Start_Date'])
X_train.Start_Date = pd.to_datetime(X_train['Start_Date'])
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date).astype('timedelta64[d]')
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date).astype('timedelta64[d]')
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date).astype('timedelta64')
X_train.Time_Difference
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date).astype('timedelta64[days]')
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date)
X_train.Time_Difference
X_train.Time_Difference.astype['timedelta64[days]']
X_train.Time_Difference[0]
X_train.Time_Difference[0].days
Diff = [X_train.Time_Difference[num].days for num in range(len(X_train))]
X_train['Time_Difference'] = Diff 
X_train['Time_Difference'] 
X_train = X_train.drop('Is_Shortlisted')
X_train = X_train.drop('Is_Shortlisted',axis=1)
%reset
y

%reset
%clear
X_train = pd.read_csv("check.csv")
X_train.Earliest_Start_Date=pd.to_datetime(X_train['Earliest_Start_Date'])
X_train.Start_Date = pd.to_datetime(X_train['Start_Date'])
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date)

#Calculating Time_Difference feature between earliest start date and Internship start date
Diff = [X_train.Time_Difference[num].days for num in range(len(X_train))]
X_train['Time_Difference'] = Diff 
import pandas as pd
X_train = pd.read_csv("check.csv")
X_train.Earliest_Start_Date=pd.to_datetime(X_train['Earliest_Start_Date'])
X_train.Start_Date = pd.to_datetime(X_train['Start_Date'])
X_train.Time_Difference = abs(X_train.Earliest_Start_Date-X_train.Start_Date)

#Calculating Time_Difference feature between earliest start date and Internship start date
Diff = [X_train.Time_Difference[num].days for num in range(len(X_train))]
X_train['Time_Difference'] = Diff 
y_train = X_train.Is_Shortlisted
y_train
X_train = X_train.drop('Is_Shortlisted')
X_train = X_train.drop('Is_Shortlisted',axis=1)
X_train = X_train.drop(['Is_Shortlisted','Earliest_Start_Date','Start_Date'],axis=1)
X_train = X_train.drop(['Earliest_Start_Date','Start_Date'],axis=1)
X_train.to_csv('training_features.csv')
from sklearn import tree
X_train = pd.read_csv('training_features.csv')
decision_tree = tree.DecisionTreeClassifier()
decision_tree.fit(X_train,y_train)
decision_tree.predict(X_train)
from sklearn.metrics import accuracy_score
accuracy_score(y_train,predictions)
predictions = decision_tree.predict(X_train)
from sklearn.metrics import accuracy_score
accuracy_score(y_train,predictions)
print (predictions)
predictions
predictions[5]
predictions[1:10]
y_train[1:10]
%clear
testing = pd.read_csv('test-date-your-data/test.csv')
testing.columns
test_raw = pd.read_csv('test-date-your-data/test.csv')
len(test_raw)
test_raw = pd.merge(test_raw,student, on='Student_ID',how='left')
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn import tree
from sklearn.metrics import accuracy_score

#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')

len(merged.columns)
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale

merged.Percentage_UG = merged.Performance_UG/merged.UG_Scale

merged['Percentage_PG']=merged.Percentage_PG
merged['Percentage_UG']=merged.Percentage_UG

merged = merged.drop(merged.columns[[14,15,16,17,18]], axis=1) 

#Converting categorical variables to numeric attributes 
merged = merged.fillna('NA')         
le = preprocessing.LabelEncoder()
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Internship_Location'] = le.fit_transform(merged.Internship_Location)
test_raw = pd.read_csv('test-date-your-data/test.csv')
len(test_raw)
test_raw = pd.merge(test_raw,student, on='Student_ID',how='left')
len(test_raw)
test_raw = pd.merge(test_raw,internship,on='Internship_ID',how='left')
len(test_raw)
test_raw.columns
test_raw = pd.read_csv('test-date-your-data/test.csv')

test_raw = pd.merge(test_raw,student, on='Student_ID',how='left')
test_raw = pd.merge(test_raw,internship,on='Internship_ID',how='left')

test_raw.Percentage_PG = test_raw.Performance_PG/test_raw.PG_scale

test_raw.Percentage_UG = test_raw.Performance_UG/test_raw.UG_Scale

test_raw['Percentage_PG']=test_raw.Percentage_PG
test_raw['Percentage_UG']=test_raw.Percentage_UG

test_raw = test_raw.drop(test_raw.columns[[14,15,16,17,18]], axis=1) 

#Converting categorical variables to numeric attributes 
test_raw = test_raw.fillna('NA')         
le = preprocessing.LabelEncoder()
test_raw['Expected_Stipend'] = le.fit_transform(test_raw.Expected_Stipend)
test_raw['Preferred_location'] = le.fit_transform(test_raw.Preferred_location)
test_raw['Institute_Category'] = le.fit_transform(test_raw.Institute_Category)
test_raw['Institute_location'] = le.fit_transform(test_raw.Institute_location)
test_raw['hometown'] = le.fit_transform(test_raw.hometown)
test_raw['Degree'] = le.fit_transform(test_raw.Degree)
test_raw['Current_year'] = le.fit_transform(test_raw.Current_year)
test_raw['Experience_Type'] = le.fit_transform(test_raw.Experience_Type)
test_raw['Location'] = le.fit_transform(test_raw.Location)
test_raw['Internship_Type'] = le.fit_transform(test_raw.Internship_Type)
test_raw['Internship_Location'] = le.fit_transform(test_raw.Internship_Location)
len(X_train)
len(X_train.columns)
test_raw = pd.read_csv('test-date-your-data/test.csv')

test_raw = pd.merge(test_raw,student, on='Student_ID',how='left')
test_raw = pd.merge(test_raw,internship,on='Internship_ID',how='left')

test_raw.Percentage_PG = test_raw.Performance_PG/test_raw.PG_scale

test_raw.Percentage_UG = test_raw.Performance_UG/test_raw.UG_Scale

test_raw['Percentage_PG']=test_raw.Percentage_PG
test_raw['Percentage_UG']=test_raw.Percentage_UG

test_raw = test_raw.drop(test_raw.columns[[14,15,16,17,18]], axis=1) 

#Converting categorical variables to numeric attributes 
test_raw = test_raw.fillna('NA')         
le = preprocessing.LabelEncoder()
test_raw['Expected_Stipend'] = le.fit_transform(test_raw.Expected_Stipend)
test_raw['Preferred_location'] = le.fit_transform(test_raw.Preferred_location)
test_raw['Institute_Category'] = le.fit_transform(test_raw.Institute_Category)
test_raw['Institute_location'] = le.fit_transform(test_raw.Institute_location)
test_raw['hometown'] = le.fit_transform(test_raw.hometown)
test_raw['Degree'] = le.fit_transform(test_raw.Degree)
test_raw['Current_year'] = le.fit_transform(test_raw.Current_year)
test_raw['Experience_Type'] = le.fit_transform(test_raw.Experience_Type)
test_raw['Location'] = le.fit_transform(test_raw.Location)
test_raw['Internship_Type'] = le.fit_transform(test_raw.Internship_Type)
test_raw['Internship_Location'] = le.fit_transform(test_raw.Internship_Location)

test_raw.Earliest_Start_Date=pd.to_datetime(test_raw['Earliest_Start_Date'])
test_raw.Start_Date = pd.to_datetime(test_raw['Start_Date'])
test_raw.Time_Difference = abs(test_raw.Earliest_Start_Date-test_raw.Start_Date)

Diff_Test = [test_raw.Time_Difference[num].days for num in range(len(test_raw))]
test_raw['Time_Difference'] = Diff_Test 
test_raw = pd.read_csv('test-date-your-data/test.csv')

test_raw = pd.merge(test_raw,student, on='Student_ID',how='left')
test_raw = pd.merge(test_raw,internship,on='Internship_ID',how='left')

test_raw.Percentage_PG = test_raw.Performance_PG/test_raw.PG_scale

test_raw.Percentage_UG = test_raw.Performance_UG/test_raw.UG_Scale

test_raw['Percentage_PG']=test_raw.Percentage_PG
test_raw['Percentage_UG']=test_raw.Percentage_UG

test_raw = test_raw.drop(test_raw.columns[[14,15,16,17,18]], axis=1) 

#Converting categorical variables to numeric attributes 
test_raw = test_raw.fillna('NA')         
le = preprocessing.LabelEncoder()
test_raw['Expected_Stipend'] = le.fit_transform(test_raw.Expected_Stipend)
test_raw['Preferred_location'] = le.fit_transform(test_raw.Preferred_location)
test_raw['Institute_Category'] = le.fit_transform(test_raw.Institute_Category)
test_raw['Institute_location'] = le.fit_transform(test_raw.Institute_location)
test_raw['hometown'] = le.fit_transform(test_raw.hometown)
test_raw['Degree'] = le.fit_transform(test_raw.Degree)
test_raw['Current_year'] = le.fit_transform(test_raw.Current_year)
test_raw['Experience_Type'] = le.fit_transform(test_raw.Experience_Type)
test_raw['Location'] = le.fit_transform(test_raw.Location)
test_raw['Internship_Type'] = le.fit_transform(test_raw.Internship_Type)
test_raw['Internship_Location'] = le.fit_transform(test_raw.Internship_Location)

test_raw.Earliest_Start_Date=pd.to_datetime(test_raw['Earliest_Start_Date'])
test_raw.Start_Date = pd.to_datetime(test_raw['Start_Date'])
test_raw.Time_Difference = abs(test_raw.Earliest_Start_Date-test_raw.Start_Date)

Diff_Test = [test_raw.Time_Difference[num].days for num in range(len(test_raw))]
test_raw['Time_Difference'] = Diff_Test 
len(test_raw)
len(test_raw.columns)
test_raw.to_csv('testing_features.csv')

train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
test_raw = pd.read_csv('test-date-your-data/test.csv')
len(train_raw)
len(train_raw)+len(test_raw)
merged = pd.concat([train_raw,test_raw])
len(merged)
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn import tree
from sklearn.metrics import accuracy_score

#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
test_raw = pd.read_csv('test-date-your-data/test.csv')
merged = pd.concat([train_raw,test_raw])
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(merged,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')
y_train = merged.Is_Shortlisted
merged = merged.drop('Is_Shortlisted')


len(merged.columns)
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale

merged.Percentage_UG = merged.Performance_UG/merged.UG_Scale

merged['Percentage_PG']=merged.Percentage_PG
merged['Percentage_UG']=merged.Percentage_UG

merged = merged.drop(merged.columns[[14,15,16,17,18]], axis=1) 


#Converting categorical variables to numeric attributes 
merged = merged.fillna('NA')         
le = preprocessing.LabelEncoder()
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Internship_Location'] = le.fit_transform(merged.Internship_Location)
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn import tree
from sklearn.metrics import accuracy_score

#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
test_raw = pd.read_csv('test-date-your-data/test.csv')
merged = pd.concat([train_raw,test_raw])
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(merged,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')
y_train = merged.Is_Shortlisted
merged = merged.drop('Is_Shortlisted',axis=1)


len(merged.columns)
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale

merged.Percentage_UG = merged.Performance_UG/merged.UG_Scale

merged['Percentage_PG']=merged.Percentage_PG
merged['Percentage_UG']=merged.Percentage_UG

merged = merged.drop(merged.columns[[14,15,16,17,18]], axis=1) 


#Converting categorical variables to numeric attributes 
merged = merged.fillna('NA')         
le = preprocessing.LabelEncoder()
merged['Expected_Stipend'] = le.fit_transform(merged.Expected_Stipend)
merged['Preferred_location'] = le.fit_transform(merged.Preferred_location)
merged['Institute_Category'] = le.fit_transform(merged.Institute_Category)
merged['Institute_location'] = le.fit_transform(merged.Institute_location)
merged['hometown'] = le.fit_transform(merged.hometown)
merged['Degree'] = le.fit_transform(merged.Degree)
merged['Current_year'] = le.fit_transform(merged.Current_year)
merged['Experience_Type'] = le.fit_transform(merged.Experience_Type)
merged['Location'] = le.fit_transform(merged.Location)
merged['Internship_Type'] = le.fit_transform(merged.Internship_Type)
merged['Internship_Location'] = le.fit_transform(merged.Internship_Location)
len(merged)
len(merged.columns)
merged.to_csv('check.csv')
runfile('C:/Users/vatsal/OneDrive/Date_Your_Data/start.py', wdir='C:/Users/vatsal/OneDrive/Date_Your_Data')
merged.columns
len(merged.columns)
merged.to_csv('final_features.csv')

X = pd.read_csv('final_features.csv')  
len(X.columns)
len(X)
len(X_train)
X_train = X[0:192583]
len(X_train)
len(y_train)
y_train[192583:len(y_train)]
y_train[0:192582]
runfile('C:/Users/vatsal/OneDrive/Date_Your_Data/start.py', wdir='C:/Users/vatsal/OneDrive/Date_Your_Data')
predictions
len(predictions)
len(X_test)
len(raw_test)

len(test_raw)
X = pd.read_csv('final_features.csv')    
X_train = X[0:180000]
X_validation = X[180001:192582]
X_test = X[192583:len(X)]


decision_tree = tree.DecisionTreeClassifier()
decision_tree.fit(X_train,y_train)

predictions = decision_tree.predict(X_validation)

accuracy_score(y_train[180001:192582],predictions)

X = pd.read_csv('final_features.csv')    
X_train = X[0:180000]
X_validation = X[180001:192582]
X_test = X[192583:len(X)]


decision_tree = tree.DecisionTreeClassifier()
decision_tree.fit(X_train,y_train[0:180000])

predictions = decision_tree.predict(X_validation)

accuracy_score(y_train[180001:192582],predictions)
final_submission = test_raw['Internship_ID','Student_ID']
final_submission = pd.DataFrame(test_raw['Internship_ID','Student_ID'])
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission.Student_ID = test_raw.Student_ID
final_submission.Is_Shortlisted=predictions
final_submission
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission['Student_ID']=final_submission.Student_ID = test_raw.Student_ID
final_submission['Is_Shortlisted']=final_submission.Is_Shortlisted=predictions

X = pd.read_csv('final_features.csv')    
X_train = X[0:192582]
#X_validation = X[180001:192582]
X_test = X[192582:len(X)]


decision_tree = tree.DecisionTreeClassifier()
decision_tree.fit(X_train,y_train)

predictions = decision_tree.predict(X_test)

# Getting the final submission file ready
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission['Student_ID']=final_submission.Student_ID = test_raw.Student_ID
final_submission['Is_Shortlisted']=final_submission.Is_Shortlisted=predictions
final_submission
final_submission.to_csv('final_submission.csv')
X_train, X_test, y_train, y_test = cross_validation.train_test_split(X, y_train, test_size=0.2, random_state=0)
decision_tree.score(X_test,y_test)
from sklearn.metrics import accuracy_score
from sklearn import cross_validation
X_train, X_test, y_train, y_test = cross_validation.train_test_split(X, y_train, test_size=0.2, random_state=0)
decision_tree.score(X_test,y_test)
X_cross_train, X_cross_test, y_crross_train, y_cross_test = cross_validation.train_test_split(X_train, y_train, test_size=0.2, random_state=0)
decision_tree.score(X_cross_test,y_cross_test)


X_cross_train, X_cross_test, y_cross_train, y_cross_test = cross_validation.train_test_split(X_train, y_train, test_size=0.2, random_state=0)
decision_tree.fit(X_cross_train,y_cross_train)
decision_tree.score(X_cross_test,y_cross_test)
scores = cross_validation.cross_val_score(decision_tree, X_train, y_train, cv=5)
print (scores)
import xgboost as xgb
import xgboost
from sklearn.ensemble import GradientBoostingClassifier
gbc = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=3, random_state=0)
scores = cross_validation.cross_val_score(gbc, X_train, y_train, cv=5)
print (scores)
X = pd.read_csv('final_features.csv')    
X_train = X[0:180000]
X_validation = X[180001:192582]
gbc = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0, max_depth=3, random_state=0)
gbc.fit(X_train,y_train[0:180000])
gbc_predictions = gbc.predict(X_validation)
print (accuracy_score(y_train[180001:192582],gbc_predictions))
gbc_predictions = gbc.predict(X_test)
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission['Student_ID']=final_submission.Student_ID = test_raw.Student_ID
final_submission['Is_Shortlisted']=final_submission.Is_Shortlisted=gbc_predictions

final_submission.to_csv('final_submission.csv')
from sklearn.ensemble import AdaBoostClassifier
abc = AdaBoostClassifier(n_estimators=100)
abc.fit(X_train,y_train[0:180000])
predictions_abc = abc.predict(X_validation)
print (accuracy_score(y_train[180001:192582],predictions_abc))
scores = cross_validation.cross_val_score(abc, X_train, y_train)
print (scores)
scores = cross_validation.cross_val_score(abc, X_train[0:192582, y_train)
print (scores)
scores = cross_validation.cross_val_score(abc, X_train[0:192582], y_train)
print (scores)
len(y_trainn)
len(y_train)

len(X_train[0:192582])
scores = cross_validation.cross_val_score(abc, X[0:192582], y_train)
print (scores)

scores.mean

scores.mean()
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission['Student_ID']=final_submission.Student_ID = test_raw.Student_ID
final_submission['Is_Shortlisted']=final_submission.Is_Shortlisted=predictions_abc

final_submission.to_csv('final_submission_abc.csv')
predictions_abc = abc.predict(X_test)
abc = AdaBoostClassifier(n_estimators=100)
abc.fit(X[0:192582],y_train)
predictions_abc = abc.predict(X_test)
final_submission = pd.DataFrame(test_raw.Internship_ID)
final_submission['Student_ID']=final_submission.Student_ID = test_raw.Student_ID
final_submission['Is_Shortlisted']=final_submission.Is_Shortlisted=predictions_abc

final_submission.to_csv('final_submission_abc.csv')
