print(result)
merged = pd.merge(train_raw,student, on='Student_ID')
len(merged)
len(raw_train)
len(train_raw)
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")

merged = pd.merge(train_raw,student, on='Student_ID')
len(merged)
merged.to_csv(check.csv)
merged.to_csv('check.csv')
left = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3'],
                         'A': ['A0', 'A1', 'A2', 'A3'],
                         'B': ['B0', 'B1', 'B2', 'B3']})

right = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3','K4','K5'],
                       'A': ['C0', 'C1', 'C2', 'C3','C4','C5'],
                       'D': ['D0', 'D1', 'D2', 'D3','D4','D5']})


result = pd.merge(left, right, on='key')
left = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3'],
                         'A': ['A0', 'A1', 'A2', 'A3'],
                         'B': ['B0', 'B1', 'B2', 'B3']})

right = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3','K4','K5'],
                       'A': ['C0', 'C1', 'C2', 'C3','C4','C5'],
                       'D': ['D0', 'D1', 'D2', 'D3','D4','D5']})


result = pd.merge(left, right, on='key')

print(left)
print(right)
print(result)
student.columns
train_raw.columns
import pandas as pd
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
student = student.drop_duplicates()
len(student)
left = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3'],
                         'A': ['A0', 'A1', 'A2', 'A3'],
                         'B': ['B0', 'B1', 'B2', 'B3']})

right = pd.DataFrame({'key': ['K0', 'K0', 'K2', 'K3','K4','K5'],
                       'A': ['C0', 'C1', 'C2', 'C3','C4','C5'],
                       'D': ['D0', 'D1', 'D2', 'D3','D4','D5']})


result = pd.merge(left, right, on='key')

print(left)
print(right)
print(result)
left = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3'],
                         'A': ['A0', 'A1', 'A2', 'A3'],
                         'B': ['B0', 'B1', 'B2', 'B3']})

right = pd.DataFrame({'key': ['K0', 'K0', 'K2', 'K3','K4','K5'],
                       'C': ['C0', 'C1', 'C2', 'C3','C4','C5'],
                       'D': ['D0', 'D1', 'D2', 'D3','D4','D5']})


result = pd.merge(left, right, on='key')

print(left)
print(right)
print(result)
left = pd.DataFrame({'key': ['K0', 'K1', 'K2', 'K3'],
                         'A': ['A0', 'A1', 'A2', 'A3'],
                         'B': ['B0', 'B1', 'B2', 'B3']})

right = pd.DataFrame({'key': ['K0', 'K0', 'K2', 'K3','K1','K5'],
                       'C': ['C0', 'C1', 'C2', 'C3','C4','C5'],
                       'D': ['D0', 'D1', 'D2', 'D3','D4','D5']})


result = pd.merge(left, right, on='key')

print(left)
print(right)
print(result)
merged = pd.merge(train_raw,student, on='Student_ID')
len(merged)
train_raw = train_raw.drop_duplicates()
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
student = student.drop_duplicates()
train_raw = train_raw.drop_duplicates()
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
len(merged)
student = student.drop_duplicates("Student_ID")
len(student)
import pandas as pd

train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
student = student.drop_duplicates("Student_ID")

merged = pd.merge(train_raw,student, on='Student_ID',how='left')
len(merged)
len(train_raw)
internship.columns
merged = pd.merge(train_raw,internship,on='Internship_ID',how='left')
len(merged)
merged.columns()
merged.columns
len(merged.columns)
runfile('C:/Users/vatsal/OneDrive/Date_Your_Data/start.py', wdir='C:/Users/vatsal/OneDrive/Date_Your_Data')
len(merged.columns)
%clear
merged.dtypes
merged.to_csv('check.csv')
for num in range(len(merged)):
    if merged['Performance_PG'][num]!= 0:
        merged['Percentage_PG'][num] =  merged['Performance_PG'][num]/merged['PG_scale'][num]  
    else:
        merged['Percentage_PG'][num] = None
    if merged['Performance_UG'][num]!=0:
        merged['Percentage_UG'][num] = merged['Performance_UG'][num]/merged['UG_Scale'][num]  
    else:
       merged['Percentage_UG'][num] = None

import numpy as np
merged['Performance_PG'] = np.random.randn(len(merged))
merged['Performance_PG'] 
merged['Percentage_PG'] = np.random.randn(len(merged))
import pandas as pd
import numpy as np
#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')

len(merged.columns)
merged['Percentage_PG'] = np.random.randn(len(merged))
merged['Percentage_UG'] = np.random.randn(len(merged))

for num in range(len(merged)):
    if merged['Performance_PG'][num]!= 0:
        merged['Percentage_PG'][num] =  merged['Performance_PG'][num]/merged['PG_scale'][num]  
    else:
        merged['Percentage_PG'][num] = None
    if merged['Performance_UG'][num]!=0:
        merged['Percentage_UG'][num] = merged['Performance_UG'][num]/merged['UG_Scale'][num]  
    else:
       merged['Percentage_UG'][num] = None

merged.Percentage_PG = merged.Percentage_UG/100
%clear
import pandas as pd
import numpy as np
#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')

len(merged.columns)
merged.Percentage_PG = merged.Percentage_UG/100
import pandas as pd
import numpy as np
#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')

len(merged.columns)
merged.Percentage_PG = merged.Performance_PG/100
merged.Percentage_PG
runfile('C:/Users/vatsal/OneDrive/Date_Your_Data/start.py', wdir='C:/Users/vatsal/OneDrive/Date_Your_Data')
merged.columns[15]
merged.columns[14]
runfile('C:/Users/vatsal/OneDrive/Date_Your_Data/start.py', wdir='C:/Users/vatsal/OneDrive/Date_Your_Data')
merged.Percentage_UG
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale
import pandas as pd
import numpy as np
#Reading the raw data files 
train_raw = pd.read_csv("trainfiles/traincsv/train.csv")
internship = pd.read_csv("trainfiles/Internship/Internship.csv")
student = pd.read_csv("trainfiles/Student/student.csv")
#Removing duplicates from the student file 
student = student.drop_duplicates("Student_ID")
#Merging all data to evaluate features and train the data 
merged = pd.merge(train_raw,student, on='Student_ID',how='left')
merged = pd.merge(merged,internship,on='Internship_ID',how='left')
merged.Percentage_PG = merged.Performance_PG/merged.PG_scale
merged
merged.columns
merged.Percentage_UG
merged.Percentage_PG
merged["Percentage_PG"]=merged.Percentage_PG
merged.Percentage_PG
%clear